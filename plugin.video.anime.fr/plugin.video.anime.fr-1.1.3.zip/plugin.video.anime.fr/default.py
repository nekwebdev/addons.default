# -*- coding: utf-8 -*-

'''
    Anime FR addon
'''

import urllib
import urllib2
import urlparse
import re
import os
import threading
import datetime
import time
import base64
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
from operator import itemgetter
try:    import json
except: import simplejson as json
try:    import CommonFunctions
except: import commonfunctionsdummy as CommonFunctions
try:    import StorageServer
except: import storageserverdummy as StorageServer
from metahandler import metahandlers
from metahandler import metacontainers

addon_handle = int(sys.argv[1])

language            = xbmcaddon.Addon().getLocalizedString
setSetting          = xbmcaddon.Addon().setSetting
getSetting          = xbmcaddon.Addon().getSetting
addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")
addonDesc           = language(40450).encode("utf-8")
addonIcon           = os.path.join(addonPath,'icon.png')
addonFanart         = os.path.join(addonPath,'fanart.jpg')
addonArt            = os.path.join(addonPath,'resources/art')
# addonPoster         = os.path.join(addonPath,'resources/art/Poster.png')
# addonDownloads      = os.path.join(addonPath,'resources/art/Downloads.png')
# addonGenres         = os.path.join(addonPath,'resources/art/Genres.png')
# addonYears          = os.path.join(addonPath,'resources/art/Years.png')
# addonLists          = os.path.join(addonPath,'resources/art/Lists.png')
addonNext           = os.path.join(addonPath,'resources/art/Next.png')
dataPath            = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
viewData            = os.path.join(dataPath,'views.cfg')
offData             = os.path.join(dataPath,'offset.cfg')
favData             = os.path.join(dataPath,'favourites.cfg')
metaget             = metahandlers.MetaData(preparezip=False)
cache               = StorageServer.StorageServer(addonName+addonVersion,1).cacheFunction
cache2              = StorageServer.StorageServer(addonName+addonVersion,12).cacheFunction
cache3              = StorageServer.StorageServer(addonName+addonVersion,720).cacheFunction
common              = CommonFunctions
action              = None

dbzseasons= ["Saison 1: l'arrivée des sayens",
            "Saison 2: Un monstre nommée Freezer",
            "Saison 3: Le Retour de Garlic Junior",
            "Saison 4: Les cyborgs",
            "Saison 5: Cell",
            "Saison 6: Encore un Tournoi !",
            "Saison 7: Boubou ! "]
def urlify(s):

     # Remove all non-word characters (everything except numbers and letters)
     s = re.sub(r"[^\w\s\-]", '', s)
     s = s.replace(" - ", "-")

     # Replace all runs of whitespace with a single dash
     s = re.sub(r"\s+", '_', s)

     return s

def log(msg):
     xbmc.log("[%s] - %s" % (addonName, msg))

def _unicode(text, encoding='utf-8'):
     try: text = unicode(text, encoding)
     except: pass
     return text

def normalize(text):
     try: text = unicodedata.normalize('NFKD', _unicode(text)).encode('utf-8')
     except: pass
     return text

class link:
    def __init__(self):
        self.hadoken = "http://hadoken-fansubs.fr/forum/"
        self.hadoken_ddl = "http://ddl.hadoken-fansubs.fr"
        # self.hadoken_streamlist = "http://hadoken-fansubs.fr/forum/viewforum.php?f=362"
        self.hadoken_streamlist = "http://hadoken-fansubs.fr/forum/viewforum.php?f=403"
        # self.hadoken_resolver = "http://ddl.hadoken-fansubs.fr/Saint%20Seiya%20Omega/"
        self.dbzhome_dblist = "http://dbzhome.net/manga.php?name=Oav-Dragon%20Ball&id=1"
        self.dbzhome_kailist = "http://dbzhome.net/manga.php?name=Episode-Dragon_Ball_Z_KAI&id=24"
        self.dbzhome_dbzseason = "http://dbzhome.net/sdbz.php?id=%d"
        self.dbzhome_narutolist = "http://dbzhome.net/manga.php?name=Oav-Naruto&id=4"
        self.dbzhome_resolver = "http://dbzhome.net/display.php?n=%s&lg=VF"
        self.dbzhome_videolink = "http://ideal.inblocks.net/screenit.php?n=%s&l=%s&lg=VF"
        self.passions_mangas = "http://www.passions-mangas.com/"
        self.anime_current = "http://www.passions-mangas.com/animes-en-cours/animes-en-cours,r316278.html"
        self.anime_finished = "http://www.passions-mangas.com/animes-complets/animes-complets,r86531.html"
        self.anime_search = "http://www.passions-mangas.com/?page=search_tag&tag=%s&sa=Rechercher"
        self.imdb_base = 'http://www.imdb.com'
        self.imdb_akas = 'http://akas.imdb.com'
        self.imdb_mobile = 'http://m.imdb.com'
        self.imdb_login = 'https://secure.imdb.com/oauth/m_login?origpath=/&ref_=m_nv_usr_lgin'
        self.imdb_added = 'http://akas.imdb.com/watchnow/'
        self.imdb_genre = 'http://akas.imdb.com/genre/'
        self.imdb_genres = 'http://akas.imdb.com/search/title?title_type=feature,tv_movie&sort=boxoffice_gross_us&count=25&start=1&genres=%s'
        self.imdb_years = 'http://akas.imdb.com/search/title?title_type=feature,tv_movie&sort=boxoffice_gross_us&count=25&start=1&&year=%s,%s'
        self.imdb_popular = 'http://akas.imdb.com/search/title?title_type=feature,tv_movie&sort=moviemeter,asc&count=25&start=1'
        self.imdb_boxoffice = 'http://akas.imdb.com/search/title?title_type=feature,tv_movie&sort=boxoffice_gross_us,desc&count=25&start=1'
        self.imdb_views = 'http://akas.imdb.com/search/title?title_type=feature,tv_movie&sort=num_votes,desc&count=25&start=1'
        self.imdb_oscars = 'http://akas.imdb.com/search/title?title_type=feature,tv_movie&groups=oscar_best_picture_winners&sort=year,desc&count=25&start=1'
        self.imdb_search = 'http://akas.imdb.com/search/title?title_type=feature,tv_movie&sort=moviemeter,asc&count=25&start=1&title=%s'
        self.imdb_user = 'http://akas.imdb.com/user/%s/lists?tab=all&sort=modified:desc&filter=titles'
        self.imdb_watchlist ='http://m.imdb.com/list/userlist_json?list_class=watchlist&limit=10000'
        self.imdb_list ='http://m.imdb.com/list/userlist_json?list_class=%s&limit=10000'

class index:
    def infoDialog(self, str, header=addonName, delay=3000):
        try: xbmcgui.Dialog().notification(header, str, addonIcon, delay, sound=False)
        except: xbmc.executebuiltin("Notification(%s,%s, %d, %s)" % (header, str, delay, addonIcon))

    def rootList(self, rootList):
        total = len(rootList)
        for i in rootList:
            try:
                name = language(i['name']).encode("utf-8")
                image = '%s/%s' % (addonArt, i['image'])
                action = i['action']
                u = '%s?action=%s' % (sys.argv[0], action)

                # cm = []

                item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=image)
                item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "Plot": addonDesc } )
                item.setProperty("Fanart_Image", addonFanart)
                # item.addContextMenuItems(cm, replaceItems=False)
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)
            except:
                pass

    def animeList(self, animeList, action, folder):
        if animeList == None: return
        total = len(animeList)
        for i in animeList:
            try:
                name, url, title = i['name'], i['url'], i['title']
                url = urllib.quote_plus(url)
                u = '%s?action=%s&url=%s&name=%s' % (sys.argv[0], action, url, name)
                item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage="")
                if not folder:
                    item.setProperty("IsPlayable", "true")
                    item.setProperty("Video", "true")
                item.setProperty("Fanart_Image", addonFanart)
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=folder)
            except:
                pass

    def videoList(self, videoList):
        if videoList == None: return

        # file = xbmcvfs.File(favData)
        # favRead = file.read()
        # file.close()

        total = len(videoList)
        for i in videoList:
            try:
                name, url, title = i['name'], i['url'], i['title']
                item = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage="")
                # item.setInfo( type="Video", infoLabels = meta )
                item.setProperty("IsPlayable", "true")
                item.setProperty("Video", "true")
                item.setProperty("Fanart_Image", addonFanart)
                # item.setProperty("art(poster)", poster)
                # item.setProperty("Fanart_Image", fanart)
                # item.addContextMenuItems(cm, replaceItems=True)
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=item,totalItems=total,isFolder=False)
            except:
                pass

    def nextList(self, nextList, action):
        try: next = nextList[0]['next']
        except: return
        if next == '': return
        name, url, image = language(30303).encode("utf-8"), next, addonNext
        sysurl = urllib.quote_plus(url)

        u = '%s?action=%s&url=%s&name=%s' % (sys.argv[0], action, sysurl, name)

        item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=image)
        # item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "Plot": addonDesc } )
        item.setProperty("Fanart_Image", addonFanart)
        # item.addContextMenuItems([], replaceItems=False)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,isFolder=True)

    def container_data(self):
        if not xbmcvfs.exists(dataPath):
            xbmcvfs.mkdir(dataPath)
        if not xbmcvfs.exists(favData):
            file = xbmcvfs.File(favData, 'w')
            file.write('')
            file.close()
        if not xbmcvfs.exists(viewData):
            file = xbmcvfs.File(viewData, 'w')
            file.write('')
            file.close()
        if not xbmcvfs.exists(offData):
            file = xbmcvfs.File(offData, 'w')
            file.write('')
            file.close()

class hadoken:
    def __init__(self):
        self.list = []

    def streamlist(self):
        # Get the complete stream list
        self.list = self.animes_list(link().hadoken_ddl)
        index().animeList(self.list, "hadoken_episodelist", True)
        index().nextList(self.list, "hadoken_episodelist")

    def videos(self, url):
        # Get the complete stream list
        self.list = self.videos_list(url)
        index().videoList(self.list)
        index().nextList(self.list, "hadoken_episodelist")

    def animes_list(self, url):
        try:
            result = getUrl(url).result
            result = result.decode('iso-8859-1').encode('utf-8')
            
            # if type == "forumtitle":
            #     itemlist = common.parseDOM(result, "dt", attrs = { "title" : "Aucun message non lu" })
            # else:
            #     itemlist = result
            animeList = common.parseDOM(result, "div", attrs = { "id" : "fallback" })
            animeList = common.parseDOM(animeList, "tr")
            # animes_name = common.parseDOM(itemlist, "span", attrs = { "class" : "label" })
            # # animes_name = common.parseDOM(itemlist, "a", attrs = { "class" : type })
            # animes_url = common.parseDOM(itemlist, "a", attrs = { "class" : type }, ret = "href")
        except:
            return

        for anime in animeList:
            try:
                name = common.parseDOM(anime, "a")
                name = name[0].encode('utf-8')
                url = common.parseDOM(anime, "a", ret = "href")
                url = link().hadoken_ddl + url[0]
                self.list.append({'name': name, 'url': url, 'title': name, 'next': ''})
            except:
                pass
        return self.list

        # try:
        #     next = common.parseDOM(result, "fieldset", attrs = { "class": "display-options" })
        #     name = common.parseDOM(next, "a", attrs = { "class": "right-box right" })[0]
        #     next = common.parseDOM(next, "a", attrs = { "class": "right-box right" }, ret="href")[0]
        #     next = next.replace("./",link().hadoken)
        #     next = common.replaceHTMLCodes(next)
        #     next = next.encode('utf-8')
        # except:
        #     next = ''

        # i = 0
        # for anime in animes_name:
        #     try:
        #         title = common.replaceHTMLCodes(anime)
        #         title = common.stripTags(title)
        #         title = title.encode('utf-8')

        #         # log(normalize(title))
        #         url = animes_url[i]
        #         i = i + 1
        #         url = common.replaceHTMLCodes(url)
        #         url = url.encode('utf-8')
        #         url = url.replace("./",link().hadoken)
        #         name = title
        #         # log(normalize(url))
        #         # log(normalize(title))

        #         self.list.append({'name': name, 'url': url, 'title': title, 'next': next})
        #     except:
        #         i = i + 1
        #         pass
        # return self.list

    def videos_list(self, url):
        try:
            result = getUrl(url).result
            result = result.decode('iso-8859-1').encode('utf-8')
            animeList = common.parseDOM(result, "div", attrs = { "id" : "fallback" })
            animeList = common.parseDOM(animeList, "tr")
            # if type == "forumtitle":
            #     itemlist = common.parseDOM(result, "dt", attrs = { "title" : "Aucun message non lu" })
            # else:
            #     itemlist = result
            # animes_name = common.parseDOM(itemlist, "a", attrs = { "class" : type })
            # animes_url = common.parseDOM(itemlist, "a", attrs = { "class" : type }, ret = "href")
        except:
            return

        for anime in animeList:
            try:
                name = common.parseDOM(anime, "a")
                name = name[0]
                if "Parent Directory" in name: continue
                if "8-bits" in name: continue
                if "PSP" in name: continue
                # name = re.search(r"\]([A-Za-z0-9_]+)\[", name)
                # name = name.group(0)
                name = name.replace("[Hadoken-Fansubs]_", "")
                name = name.encode('utf-8')
                log(normalize(name))
                url = common.parseDOM(anime, "a", ret = "href")
                url = link().hadoken_ddl + url[0]
                log(normalize(url))
                self.list.append({'name': name, 'url': url, 'title': name, 'next': ''})
            except:
                pass
        return self.list

        # try:
        #     next = common.parseDOM(result, "fieldset", attrs = { "class": "display-options" })
        #     name = common.parseDOM(next, "a", attrs = { "class": "right-box right" })[0]
        #     next = common.parseDOM(next, "a", attrs = { "class": "right-box right" }, ret="href")[0]
        #     next = next.replace("./",link().hadoken)
        #     next = common.replaceHTMLCodes(next)
        #     next = next.encode('utf-8')
        # except:
        #     next = ''

        # i = 0
        # for anime in animes_name:
        #     try:
        #         title = common.replaceHTMLCodes(anime)
        #         title = common.stripTags(title)
        #         title = title.encode('utf-8')
        #         # log(normalize(title))
        #         if not "Version" in title:
        #             if not "Lien" in title:                 
        #                 url = animes_url[i]
        #                 i = i + 1
        #                 url = common.replaceHTMLCodes(url)
        #                 url = url.encode('utf-8')
        #                 url = url.replace("./",link().hadoken)
        #                 # log(normalize(url))
        #                 # log(normalize(title))
        #                 name = title
        #                 self.list.append({'name': name, 'url': url, 'title': title,'next': next})
        #                 pass
        #         i = i + 1
        #     except:
        #         i = i + 1
        #         pass
        return self.list

class dbzhome:
    def __init__(self):
        self.list = []

    def dragonball(self):
        # Get Dragon Ball episodes list
        self.list = cache2(self.db_list, link().dbzhome_dblist)
        index().animeList(self.list, "resolve_dbzhome", False)

    def dbz(self):
        # Display Seasons
        i = 1
        total = len(dbzseasons)
        for season in dbzseasons:
            try:
                url = link().dbzhome_dbzseason % i
                i = i + 1
                url = urllib.quote_plus(url)
                u = '%s?action=dbzhome_dbz_list&url=%s' % (sys.argv[0], url)
                item = xbmcgui.ListItem(season, iconImage="DefaultFolder.png", thumbnailImage="")
                item.setProperty("Fanart_Image", addonFanart)
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)
            except:
                i = i + 1
                pass

    def naruto(self):
        # get Naruto episodes list
        self.list = cache2(self.db_list, link().dbzhome_narutolist)
        index().animeList(self.list, "resolve_dbzhome", False)

    def dbz_season(self, url):
        self.list = cache2(self.dbz_list, url)
        index().animeList(self.list, "resolve_dbzhome", False)

    def kai(self):
        self.list = cache2(self.db_list, link().dbzhome_kailist)
        index().animeList(self.list, "resolve_dbzhome", False)

    def dbz_list(self, url):
        try:
            result = getUrl(url).result
            result = result.decode('iso-8859-1').encode('utf-8')
            content = common.parseDOM(result, "div", attrs = { "style": "margin-left:100px;margin-top:2px;" })
            animes_name = common.parseDOM(content, "a", attrs = { "href" : ".+?" })
            animes_url = common.parseDOM(content, "a", attrs = { "href" : ".+?" }, ret = "href")
            # animes = dict(zip(animes_name, animes_url))
            # log(normalize(animes))
        except:
            return

        i = 0
        for anime in animes_name:
            try:
                title = common.replaceHTMLCodes(anime)
                title = common.stripTags(title)
                title = title.encode('utf-8')

                if "Episode" in title:
                    try:
                        url = animes_url[i]
                        i = i + 1
                        parsed = urlparse.urlparse(url)
                        url = urlparse.parse_qs(parsed.query)['n']
                        url = url[0]
                        name = title

                        self.list.append({'name': name, 'url': url, 'title': title})
                    except:
                        pass
                else:
                    i = i + 1
            except:
                i = i + 1
                pass
        return self.list
         
    def db_list(self, url):
        try:
            result = getUrl(url).result
            result = result.decode('iso-8859-1').encode('utf-8')
            content = common.parseDOM(result, "div", attrs = { "style": "margin-left:15px;margin-top:20px;" })
            animes_name = common.parseDOM(content, "a", attrs = { "href" : ".+?" })
            animes_url = common.parseDOM(content, "a", attrs = { "href" : ".+?" }, ret = "href")
            # animes = dict(zip(animes_name, animes_url))
            # log(normalize(animes))
        except:
            return

        i = 0
        for anime in animes_name:
            try:
                title = common.replaceHTMLCodes(anime)
                title = common.stripTags(title)
                title = title.encode('utf-8')

                if "Episode" in title:
                    try:
                        url = animes_url[i]
                        i = i + 1
                        parsed = urlparse.urlparse(url)
                        url = urlparse.parse_qs(parsed.query)['n']
                        url = url[0]
                        name = title

                        self.list.append({'name': name, 'url': url, 'title': title})
                    except:
                        pass
                else:
                    i = i + 1
            except:
                i = i + 1
                pass
        return self.list

class passions:
    def __init__(self):
        self.list = []

    def current(self):
        # Get anime list
        self.list = cache2(self.anime_list, link().anime_current)
        index().animeList(self.list, "season", True)

    def finished(self):
        # Get anime list
        self.list = cache2(self.anime_list, link().anime_finished)
        index().animeList(self.list, "season", True)
    
    def seasons(self, url):
        # Get Seasons list
        self.list = cache2(self.anime_season, url)
        index().animeList(self.list, "videos", True)

    def videos(self, url):
        # Get Seasons list
        self.list = cache2(self.anime_videos, url)
        index().videoList(self.list)

    def search(self, query=None):
        if query is None:
            self.query = common.getUserInput(language(30362).encode("utf-8"), '')
        else:
            self.query = query
        if not (self.query is None or self.query == ''):
            # log(normalize(self.query))
            self.query = link().anime_search % urllib.quote_plus(self.query)
            # log(normalize(self.query))
            self.list = self.anime_search(self.query)
            index().animeList(self.list, "videos")

    def anime_list(self, url):
        try:
            result = getUrl(url).result
            result = result.decode('iso-8859-1').encode('utf-8')
            content = common.parseDOM(result, "div", attrs = { "class": "message_middle_content" })
            animelist = common.parseDOM(content, "p")
            animes_name = common.parseDOM(animelist, "a", attrs = { "href" : ".+?" })
            animes_url = common.parseDOM(animelist, "a", attrs = { "href" : ".+?" }, ret = "href")
        except:
            return

        i = 0
        for anime in animes_name:
            try:
                title = common.replaceHTMLCodes(anime)
                title = common.stripTags(title)
                title = title.encode('utf-8')

                url = animes_url[i]
                i = i + 1
                url = common.replaceHTMLCodes(url)
                url = url.encode('utf-8')

                name = title

                self.list.append({'name': name, 'url': url, 'title': title})
            except:
                i = i + 1
        return self.list

    def anime_season(self, url):
        try:
            result = getUrl(url).result
            result = result.decode('iso-8859-1').encode('utf-8')
            content = common.parseDOM(result, "div", attrs = { "id": "fiche" })
            if not content:
                content = common.parseDOM(result, "div", attrs = { "style": "text-align: center;" })
           
            seasons_name = common.parseDOM(content, "a", attrs = { "href" : ".+?" })
            seasons_url = common.parseDOM(content, "a", attrs = { "href" : ".+?" }, ret = "href")
        except:
            return

        i = 0
        for season in seasons_name:
            try:
                title = common.replaceHTMLCodes(season)
                title = common.stripTags(title)
                title = title.encode('utf-8')

                if "Episode" in title:
                    try:
                        url = seasons_url[i]
                        i = i + 1
                        url = common.replaceHTMLCodes(url)
                        url = url.encode('utf-8')

                        name = title

                        self.list.append({'name': name, 'url': url, 'title': title})
                    except:
                        pass
                else:
                    i = i + 1
            except:
                i = i + 1
                pass
        return self.list

    def anime_videos(self, url):
        try:
            result = getUrl(url).result
            result = result.decode('iso-8859-1').encode('utf-8')
            videos_name = common.parseDOM(result, "span", attrs = { "class" : "episode" })
            videos_url = common.parseDOM(result, "object", attrs = { "data" : ".+?" }, ret = "data")
        except:
            return

        i = 0
        for video in videos_name:
            try:
                title = common.replaceHTMLCodes(video)
                title = common.stripTags(title)
                title = title.encode('utf-8')

                url = videos_url[i]
                i = i + 1
                url = common.replaceHTMLCodes(url)
                url = url.encode('utf-8')
                url = url.rsplit('/',1)[1]
                url = resolver().rutube(url)

                name = title

                self.list.append({'name': name, 'url': url, 'title': title})
            except:
                i = i + 1
                pass
        return self.list

    def anime_search(self, url):
        try:
            result = getUrl(url).result
            result = result.decode('iso-8859-1').encode('utf-8')
            content = common.parseDOM(result, "div", attrs = { "class": "message_middle_content" })
           
            results_name = common.parseDOM(content, "h2", attrs = { "style" : "font-size: 14px;font-weight:bold; margin:0" })
            results_url = common.parseDOM(content, "div", attrs = { "style" : "border-bottom: 1px dashed #CCC;margin-top: 20px;padding-bottom: 15px;" })
        except:
            return

        i = 0
        for item in results_name:
            try:
                title = common.replaceHTMLCodes(item)
                title = common.stripTags(title)
                title = title.encode('utf-8')

                url = results_url[i]
                i = i + 1
                url = common.parseDOM(url, "a", ret = "href" )
                url = url[0]
                url = common.replaceHTMLCodes(url)
                url = url.encode('utf-8')
                url = url.replace("./",link().passions_mangas)

                name = title

                self.list.append({'name': name, 'url': url, 'title': title})
                pass
            except:
                i = i + 1
                pass
        return self.list

class resolver:
    def hadoken(self, name, url):
        try:
            base = "http://ddl.hadoken-fansubs.fr"
            # log(normalize(base))
            # log(normalize(name))
            # log(normalize(url))
            result = getUrl(url).result
            result = result.decode('iso-8859-1').encode('utf-8')
            ddl = common.parseDOM(result, "a", attrs= {"class": "postlink"}, ret= "href")
            # log(normalize(ddl))
            for link in ddl:
                # log(normalize(link))
                link = link.lstrip('/').split("/")
                if link[2] == "ddl.hadoken-fansubs.fr":
                    ddl = link[3]
                    # log(normalize(ddl))
                    break
            # ddl = ddl[0]
            # ddl = ddl.lstrip('/').split("/")
            # ddl = ddl[3]
            ddl = base + "/" + ddl
            # log(normalize(ddl))
            result = getUrl(ddl).result
            result = result.decode('iso-8859-1').encode('utf-8')
            links = common.parseDOM(result, "a", ret= "href")
            # encname = name.replace(" : ", "")
            # encname = encname.replace(" ", "_")
            encname = urlify(name)
            encname = encname.replace("_VOSTFR", "")
            # Dirty fix for Utawarerumono bad naming in ddl
            if "Utawarerumono" in encname:
                # log(normalize("Fix Utawarerumono"))
                encname = encname.replace("Utawarerumono", "Utawararerumono")
            if "Saint_Seiya_Tenkai_Hen_Jos" in encname:
                # log(normalize("Fix Saint Seiya Film"))
                encname == "Saint_Seiya_Tenkai-hen_Joso-Overture_Film-5_Full-HD-1080p_8-bits"
            # log(normalize(encname))
            # encv1 = encname.replace("_VOSTFR", "_HD_8-bits")
            # encv2 = encname.replace("_VOSTFR", "v2_HD_8-bits")
            # log(normalize(encv1))
            # log(normalize(encv2))
            # log(normalize(result))
            for link in links:
                # log(normalize(link))
                if encname in link:
                    # log(normalize("Name match!"))
                    # log(normalize(link))
                    if not "10-bits" in link:
                        # not a 10-bits link, so far so good.
                        if "8-bits" in link:
                            # log(normalize("8-bits match!"))
                            url = base + link
                            # log(normalize(url))
                            break
                        # log(normalize("v2"))
                        url = base + link
                        # log(normalize(url))
                        break
                # log(normalize("Wrong link!"))



                # if encv1 in link:
                #     # log(normalize("v1"))
                #     # log(normalize(link))
                #     url = base + link
                #     # log(normalize(url))
                #     break
                # else:
                #     encname = encname.replace("v2", "")
                #     if encname in link:
                        # log(normalize(link))
                #         url = base + link
                #         break

            # log(normalize(url))
            # name = name.encode('utf-8')
            item = xbmcgui.ListItem(path=url)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


            # name = common.parseDOM(result, "h3", attrs= {"class": "first"})
            # name = common.parseDOM(name, "a")
            # all_links = getUrl(link().hadoken_resolver).result
            # all_links = all_links.decode('iso-8859-1').encode('utf-8')
            # links = 
            # log(normalize(name))
            # for url in urls:
            #     if "HD 8-bits"
        except:
            index().infoDialog(language(30302).encode("utf-8"), addonName, 5000)
            return
    def dbzhome(self, url):
        try:
            f_url = False
            url = link().dbzhome_resolver % (url)
            result = getUrl(url).result
            result = result.decode('iso-8859-1').encode('utf-8')
            # table = common.parseDOM(result, "TABLE", attrs = { "class" : "all_links" })
            # if not table:
            #     table = common.parseDOM(result, "table", attrs = { "class" : "all_links" })
            url = common.parseDOM(result, "a", attrs = { "class" : "red_link" }, ret = "href")
            url = url[0]
            xbmc.sleep(2000)
            result = getUrl(url).result
            result = result.decode('iso-8859-1').encode('utf-8')
            name = common.parseDOM(result, "span", attrs = { "class" : "texte" })
            name = name[0]
            name = name.encode('utf-8')
            r_url = common.parseDOM(result, "PARAM", attrs = { "name" : "movie" }, ret = "value")
            if not r_url:
                r_url = common.parseDOM(result, "param", attrs = { "name" : "movie" }, ret = "value")
                if not r_url:
                    r_url = r_url = common.parseDOM(result, "param", attrs = { "name" : "data" }, ret = "value")
            if r_url:
                r_url = r_url[0]
                s_url = r_url.rsplit('/',1)[1]
                f_url = self.rutube(s_url)
            if not f_url:
                import urlresolver
                if r_url:
                    url = r_url
                else:
                    url = common.parseDOM(result, "iframe", attrs = { "id" : "nimbb" }, ret = "src")
                    url = url[0]
                host = urlresolver.HostedMediaFile(url)
                if host: resolver = urlresolver.resolve(url)
                if not resolver.startswith('http://'): return
                if not resolver == url: f_url = resolver
            item = xbmcgui.ListItem(path=f_url)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
        except:
            index().infoDialog(language(30302).encode("utf-8"), addonName, 5000)
            return

    def rutube(self, url):
        try:
            # url = 'http://rutube.ru/api/play/trackinfo/%s/?no_404=true&sqr4374_compat=1&format=xml' % url
            # result = getUrl(url).result
            # url = re.compile('<m3u8>(.+?)</m3u8>').findall(result)[0]
            url = 'http://bl.rutube.ru/%s.m3u8' % url
            return url
        except:
            return

class getUrl(object):
    def __init__(self, url, close=True, proxy=None, post=None, mobile=False, referer=None, cookie=None, output='', timeout='10'):
        if not proxy is None:
            proxy_handler = urllib2.ProxyHandler({'http':'%s' % (proxy)})
            opener = urllib2.build_opener(proxy_handler, urllib2.HTTPHandler)
            opener = urllib2.install_opener(opener)
        if output == 'cookie' or not close == True:
            import cookielib
            cookie_handler = urllib2.HTTPCookieProcessor(cookielib.LWPCookieJar())
            opener = urllib2.build_opener(cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
            opener = urllib2.install_opener(opener)
        if not post is None:
            request = urllib2.Request(url, post)
        else:
            request = urllib2.Request(url,None)
        if mobile == True:
            request.add_header('User-Agent', 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_0 like Mac OS X; en-us) AppleWebKit/532.9 (KHTML, like Gecko) Version/4.0.5 Mobile/8A293 Safari/6531.22.7')
        else:
            request.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0')
        if not referer is None:
            request.add_header('Referer', referer)
        if not cookie is None:
            request.add_header('cookie', cookie)
        response = urllib2.urlopen(request, timeout=int(timeout))
        if output == 'cookie':
            result = str(response.headers.get('Set-Cookie'))
        elif output == 'geturl':
            result = response.geturl()
        else:
            result = response.read()
        if close == True:
            response.close()
        self.result = result

class root:
    def get(self):
        rootList = []
        rootList.append({'name': 30505, 'image': 'vf.png', 'action': 'vf'})
        rootList.append({'name': 30506, 'image': 'vostfr.png', 'action': 'vostfr'})
        index().rootList(rootList)

    def vostfr(self):
        rootList = []
        rootList.append({'name': 30508, 'image': 'vostfr.png', 'action': 'vostfr_mix'})
        rootList.append({'name': 30509, 'image': 'vostfr.png', 'action': 'vostfr_hadoken'})
        index().rootList(rootList)

    def vostfr_mix(self):
        rootList = []
        rootList.append({'name': 30501, 'image': 'Favourites.png', 'action': 'anime_current'})
        rootList.append({'name': 30502, 'image': 'Favourites.png', 'action': 'anime_finished'})
        rootList.append({'name': 30503, 'image': 'Favourites.png', 'action': 'anime_genre'})
        rootList.append({'name': 30504, 'image': 'Favourites.png', 'action': 'anime_search'})
        index().rootList(rootList)

    def vf(self):
        rootList = []
        rootList.append({'name': 30601, 'image': 'dragonball.png', 'action': 'dbzhome_db'})
        rootList.append({'name': 30602, 'image': 'dbz.png', 'action': 'dbzhome_dbz'})
        rootList.append({'name': 30603, 'image': 'dbzkai.png', 'action': 'dbzhome_kai'})
        rootList.append({'name': 30604, 'image': 'dbzkai.png', 'action': 'dbzhome_naruto'})

        index().rootList(rootList)

class main:
    def __init__(self):
        # log(normalize("Hello1"))
        # print rutube('81eb00642f8b7bba23aac97d204a0f38')
        # li = xbmcgui.ListItem('My First Video!')
        # url = rutube('81eb00642f8b7bba23aac97d204a0f38')
        # xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
        # xbmcplugin.endOfDirectory(addon_handle)
        
        global action
        index().container_data()
        params = {}
        splitparams = sys.argv[2][sys.argv[2].find('?') + 1:].split('&')
        for param in splitparams:
            if (len(param) > 0):
                splitparam = param.split('=')
                key = splitparam[0]
                try:    value = splitparam[1].encode("utf-8")
                except: value = splitparam[1]
                params[key] = value

        try:        action = urllib.unquote_plus(params["action"])
        except:     action = None
        try:        name = urllib.unquote_plus(params["name"])
        except:     name = None
        try:        url = urllib.unquote_plus(params["url"])
        except:     url = None
        try:        query = urllib.unquote_plus(params["query"])
        except:     query = None

        if action == None: root().get()
        if action == "vf": root().vf()
        if action == "vostfr": root().vostfr()
        if action == "vostfr_mix": root().vostfr_mix()
        if action == "vostfr_hadoken": hadoken().streamlist()
        if action == "anime_current": passions().current()
        if action == "anime_finished": passions().finished()
        if action == "anime_search": passions().search(query)
        if action == "season": passions().seasons(url)
        if action == "videos": passions().videos(url)
        if action == "hadoken_episodelist": hadoken().videos(url)
        if action == "dbzhome_db": dbzhome().dragonball()
        if action == "dbzhome_dbz": dbzhome().dbz()
        if action == "dbzhome_kai": dbzhome().kai()
        if action == "dbzhome_naruto": dbzhome().naruto()
        if action == "dbzhome_dbz_list": dbzhome().dbz_season(url)
        if action == "resolve_dbzhome": resolver().dbzhome(url)
        if action == "resolve_hadoken": resolver().hadoken(name, url)

        xbmcplugin.endOfDirectory(int(sys.argv[1]))


        # Print the root list:
        # xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
        
        # player().run("testing ", rutube('81eb00642f8b7bba23aac97d204a0f38'))

main()