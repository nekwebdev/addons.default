# -*- coding: UTF-8 -*-

import urllib, urllib2, re, os

def stream_decoder(url):
    vid = ''.join(re.findall('playpath=(.*?) swfVfy', url))
    ref_url = 'http://www.teledunet.com/?channel='+vid
    req = urllib2.Request("http://www.teledunet.com/tv_/?channel="+vid+"&no_pub")
    req.add_unredirected_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.64 Safari/537.31')
    req.add_header('Referer', ref_url)
    try:
        f = urllib2.urlopen(req)
        for line in f.readlines():
            if 'curent_media=' in line:
                rtmp_url = re.findall('curent_media=\'(.*?)\';', line)
            if 'time_player' in line:
                time_url = re.findall('time_player=(.*?);', line)
        url = rtmp_url[0]+' swfUrl=http://www.teledunet.com/player.swf?id0='+time_url[0].replace('.','').replace('E+13','00')+'&skin=bekle/bekle.xml&channel= pageUrl='+ref_url+' live=true swfVfy=true timeout=30'
        return url
    except:
        return url
