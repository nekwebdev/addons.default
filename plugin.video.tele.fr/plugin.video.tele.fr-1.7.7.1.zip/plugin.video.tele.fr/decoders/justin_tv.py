# -*- coding: UTF-8 -*-

import urllib, urllib2, re

try:
    import json
except:
    import simplejson as json

def stream_decoder(url):
    channel_name = url.split("channel=")
    req = urllib2.Request('https://api.twitch.tv/api/channels/'+channel_name[1]+'/access_token?as3=t')
    req.add_unredirected_header('User-agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0')
    req.add_header('Referer', 'http://www.justin.tv/')
    response = urllib2.urlopen(req)
    data = json.loads(response.read())
    params = ['nauthsig=%s' %data['sig'],'player=jtvweb','private_code=null','type=any','nauth=%s' %urllib2.quote(data['token']),'allow_source=true',]
    stream_url = 'http://usher.twitch.tv/select/'+channel_name[1]+'.json?'+'&'.join(params)
    return stream_url
