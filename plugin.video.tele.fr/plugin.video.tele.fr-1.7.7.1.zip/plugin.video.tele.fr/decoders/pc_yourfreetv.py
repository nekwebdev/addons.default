# -*- coding: UTF-8 -*-

import urllib, urllib2, re


def stream_decoder(url):
    channel_id = url.replace('http://pc-yourfreetv.com/?channel=','')
    ref_url = 'http://pc-yourfreetv.com/international.php'
    req = urllib2.Request(ref_url)
    req.add_unredirected_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.64 Safari/537.31')
    req.add_header('Referer', ref_url)
    try:
        f = urllib2.urlopen(req)
        for line in f.readlines():
            if '='+channel_id+'&auth=' in line:
                token_url = re.findall('<option  value="(.*?)">(.*?)</option>', line)
                url = "http://pc-yourfreetv.com"+token_url[0][0].replace(' ','%20')
		req = urllib2.Request(url)
		req.add_unredirected_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.64 Safari/537.31')
		req.add_header('Referer', ref_url)
        try:
            f = urllib2.urlopen(req)
            for line in f.readlines():
                if 'jwplayer' in line:
                    token_url = re.findall("'file':'(.*?)','skin'", line)
                    url = token_url[0]
            return url
        except:
            return url
        return url
    except:
        return url
