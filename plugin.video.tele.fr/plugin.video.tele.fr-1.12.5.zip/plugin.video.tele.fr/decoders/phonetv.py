# -*- coding: UTF-8 -*-

import urllib, urllib2, re, os
import base64, string

def unpackjs(p, a, c, k):
    digs = ["0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"];
    l = list(p)
    k = k.split('|')
    for i in range(int(c)-1,0,-1):
        if k[i]:
            for index, item in enumerate(l):
                if item == digs[i]:
                    l[index] = k[i]
    return "".join(l)

def stream_decoder(url):
    try:
        req = urllib2.Request(url)
        f = urllib2.urlopen(req)
        html = f.read()
        embed_url = re.findall('atob\("(.*?)"', html)
        html = urllib.unquote(base64.b64decode(embed_url[0]))
        while (re.findall('atob\("(.*?)"', html)):
            embed_url = re.findall('atob\("(.*?)"', html)
            html = urllib.unquote(base64.b64decode(embed_url[0]))
            print html
        code2 = re.findall('eval\(function\(p,a,c,k,e,(?:r|d)\){.*?}\(\'(.*?)\', *(\d+), *(\d+), *\'(.*?)\'\.split\(\'\|\'\)(.*?\)\)|\)\))', html)
        code3 = unpackjs(code2[0][0],code2[0][1],code2[0][2],code2[0][3])
        m3u8_url = re.findall('="(.*?)";', code3)
        return m3u8_url[0]
    except:
        return url
        
