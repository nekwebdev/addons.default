# -*- coding: UTF-8 -*-

import urllib, urllib2, re, datetime

def stream_decoder(url):
    ref = 'http://www.livetv.tn'
    vid = re.findall('playpath=(.*?) swfUrl=(.*?) pageUrl=(.*?) tcUrl', url)
    values = {'captcah':'1feaef', 'submit':'Envoyer' }
    data = urllib.urlencode(values)
    req = urllib2.Request(vid[0][2],data)
    req.add_unredirected_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36')
    req.add_header('Referer', ref)
    try:
        f = urllib2.urlopen(req)
        code1 = re.findall('unescape\(\'(.*?)\'\)\)\;', f.read())
        code2 = re.findall('url: "(.*?)"', urllib.unquote(code1[0]))
        url = url.replace(vid[0][0],code2[0])
        url = url.replace(vid[0][2], ref)
        return url
    except:
        return url


