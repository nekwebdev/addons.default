# -*- coding: UTF-8 -*-

import urllib2, re

def stream_decoder(url):
    vid = re.findall('playpath=(.*?) swfUrl=(.*?) pageUrl=(.*?) ', url)
    opener = urllib2.build_opener()
    opener.addheaders.append(('Cookie', 'SESSbae7a87956c79f1520e34d92d94d99a8=9Xgx6AuVbhYRmwMU7pt27Z_66B-DW9eiAoBJt7ASu0s'))
    try:
        response = opener.open(vid[0][2])
        data = response.read()
        token = re.findall(vid[0][0]+'\?st=(.*?)"', data)
        url = url.replace(vid[0][0],vid[0][0]+'?st='+token[0])
        return url    
    except:
        return url
