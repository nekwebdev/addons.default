# -*- coding: UTF-8 -*-

import urllib, urllib2, re, base64

def stream_decoder(url):
    vid = ''.join(re.findall('(.*?) swfVfy', url))
    print "XBMC Télé Fr - open: "+vid
    req = urllib2.Request(vid)
    req.add_header('User-agent', 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16')
    req.add_header('Referer', 'http://www.streamfoot.info/stream/')
    try:
        f = urllib2.urlopen(req)
        html = f.read()
        embed_url = re.findall('hdcastream.info/(.*?)"', html)
        new_url = "http://www.hdcastream.info/"+embed_url[0]
        print "XBMC Télé Fr - open: "+new_url
        req = urllib2.Request(new_url)
        req.add_header('User-agent', 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16')
        req.add_header('Referer', vid)
        f = urllib2.urlopen(req)
        html = f.read()
        print html
        ssx1 = re.findall('id="ssx1" value="(.*?)"', html)
        ssx4 = re.findall('id="ssx4" value="(.*?)"', html)
        rtmp = base64.b64decode(ssx4[0]).split("/redirect/");
        url = url.replace(vid,rtmp[0]+" app=vod/"+rtmp[1]+" playpath="+base64.b64decode(ssx1[0])+" swfUrl=http://www.hdmytv.com/jwplayer5/addplayer/jwplayer.flash.swf pageUrl=http://www.hdcastream.info")
        print "XBMC Télé Fr - send: "+url
        return url
    except:
        return url        
