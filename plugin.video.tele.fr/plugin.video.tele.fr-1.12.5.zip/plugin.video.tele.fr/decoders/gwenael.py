# -*- coding: UTF-8 -*-

import urllib, urllib2, re, os, json
import base64
from datetime import datetime

def stream_decoder(url):
    return url+"&t="+base64.b64encode(datetime.utcnow().strftime('%H%m%Y%d'))
